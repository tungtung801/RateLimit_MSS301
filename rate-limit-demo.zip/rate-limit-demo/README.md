# Demo: Bucket4j + Spring Cloud Gateway Rate Limiter

Hai project nhỏ đi kèm video:

1. ticket-service/  : API bán vé (Spring Boot 3, Java 17) + Bucket4j trong Filter  -> cổng 8081
2. api-gateway/     : Spring Cloud Gateway + RequestRateLimiter + Redis           -> cổng 8080
3. docker-compose.yml: chạy Redis (cổng 6379)
4. scripts/spam.sh  : bắn request để xem mã 429

## Chạy nhanh
```bash
docker compose up -d                 # bật Redis
cd ticket-service && ./mvnw spring-boot:run   # hoặc: mvn spring-boot:run
cd api-gateway    && ./mvnw spring-boot:run
bash scripts/spam.sh                 # xem 200 ... rồi 429
```

## Quan sát
- Gọi thẳng :8081 -> Bucket4j (mỗi IP 10 request / phút, burst 10).
- Gọi qua :8080  -> Gateway (replenishRate 10, burstCapacity 20) rồi mới tới ticket-service.
- Header trả về: X-RateLimit-Remaining, X-RateLimit-Burst-Capacity, X-RateLimit-Replenish-Rate.

## Lưu ý phiên bản
- Spring Cloud 2023.0.x (Boot 3.3.x) dùng tiền tố  spring.cloud.gateway.routes
- Từ Spring Cloud 2025.0 tiền tố có thể đổi thành spring.cloud.gateway.server.webflux.routes
  -> luôn đối chiếu tài liệu đúng phiên bản bạn dùng.
